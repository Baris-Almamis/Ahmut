#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
srand(time(NULL));
int rastgele, sayi, fark, tahmin;
tahmin=0;
printf("Olamaz Seamus'un iyi dostu Ahmut saklandi, Ahmut'u bulmama yardim eder misin? \n");
printf("Sayi giriniz \n");
scanf("%d", &sayi);
rastgele=rand()%100;
while (sayi!=rastgele){
if((sayi>0)&&(sayi<100)){
tahmin++;
fark=rastgele-sayi;
if (fark<0) {
	printf("sayin tuttugum sayidan buyuk \n");
	fark=-fark;
}
else
	printf("tuttugum sayi senin sayindan buyuk \n");
if (fark>25)
		printf("uzaksin \n");
else if (fark>10)
		printf("yakinsin \n");
else
	printf("cok yakinsin \n");
	scanf("%d",&sayi);
}
else {
	printf("Hatali deger girdiniz (Sayiniz 0 ile 100 arsinda olmali). \n");
	scanf("%d",&sayi);
	fflush(stdin);
}
}
if(rastgele==sayi) {
	tahmin++;
	system("ahmut.jpg");
	printf("%d tahminde Ahmut'u buldunuz! \n",tahmin);
}
getch();
return 0;
}
